SBL 1.0 resolved page rendering package
Render target: CH13-P060
Entry file: CH13-P060.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Midori-Production-Academy.png
  Assets/Eliane Character Sheet.png
  Assets/Midori-Academy-Uniform-Production-Sheet.png
  Assets/Brienmay-production-sheet.png
  Assets/Faculty-Deliberation-Room.png
  Assets/Celeste-Character-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
