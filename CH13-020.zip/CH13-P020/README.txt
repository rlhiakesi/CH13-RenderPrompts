SBL 1.0 resolved page rendering package
Render target: CH13-P020
Entry file: CH13-P020.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Academy-Uniform-Female.png
  Assets/Celeste-Character-Sheet.png
  Assets/Midori-Academy-Uniform-Production-Sheet.png
  Assets/Taren-Character-Sheet.png
  Assets/Beli-production-sheet.png
  Assets/Buren-Character-Sheet.png
  Assets/Kenee-Character-Sheet.png
  Assets/Firma-Magic-Station-Reference-Sheet.png
  Assets/Midori-Production-Academy.png
  Assets/Academy-Uniform-Male.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
