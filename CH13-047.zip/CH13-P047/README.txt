SBL 1.0 resolved page rendering package
Render target: CH13-P047
Entry file: CH13-P047.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Buren-Character-Sheet.png
  Assets/Beli-production-sheet.png
  Assets/Bali-Character-Reference-Sheet.png
  Assets/Zoran-Settlement-Mana-Installation-Reference-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
